# MonsterPanel

A small FastAPI panel for hosting authorized Python/Telegram bots.

## Telegram bot workflow

1. Open **Tokens & Chat ID**.
2. Select a bot.
3. Save its Telegram BotFather token and optional chat ID.
4. Start the bot from the dashboard.
5. View its logs and restart/stop it when needed.

The included `bots/telegram_starter.py` is a minimal, benign example.

## Security

Do not commit bot tokens, passwords, session strings, or `.env` files to GitHub.
Use Monster environment variables and an encrypted persistent store for production.

Only run bots you own or are authorized to operate. Avoid unsolicited messaging, flooding, or attempts to bypass Telegram rate limits.
