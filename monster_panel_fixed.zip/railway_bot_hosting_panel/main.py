import os
import sys
import subprocess
import threading
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, Request, Form, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

BASE = Path(__file__).parent
BOT_DIR = BASE / "bots"
BOT_DIR.mkdir(exist_ok=True)

app = FastAPI(title="Bot Hosting Panel")
app.add_middleware(
    SessionMiddleware,
    secret_key=os.getenv("SESSION_SECRET", "replace-this-in-Monster")
)
templates = Jinja2Templates(directory=str(BASE / "templates"))
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")

USER = os.getenv("PANEL_USER", "admin")
PASSWORD = os.getenv("PANEL_PASSWORD", "change-me")

# Runtime state. This is intentionally in memory, matching the original panel.
processes = {}
logs = {}
process_meta = {}
state_lock = threading.Lock()
MAX_LOG_LINES = 500

# Credentials are kept outside the Git repository. For production, replace this
# in-memory store with an encrypted database/secret manager.
credentials = {}


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def append_log(bot_id, message):
    """Append a timestamped log line and keep memory bounded."""
    line = f"[{now()}] {message}"
    with state_lock:
        bucket = logs.setdefault(bot_id, [])
        bucket.append(line)
        if len(bucket) > MAX_LOG_LINES:
            del bucket[:-MAX_LOG_LINES]


def logged(request):
    return bool(request.session.get("user"))


def status(bot_id):
    with state_lock:
        p = processes.get(bot_id)
    return "running" if p and p.poll() is None else "stopped"


def bot_environment(bot_id):
    env = os.environ.copy()
    cred = credentials.get(bot_id, {})
    if cred.get("token"):
        env["BOT_TOKEN"] = cred["token"]
        env["TELEGRAM_BOT_TOKEN"] = cred["token"]
    if cred.get("chat_id"):
        env["CHAT_ID"] = cred["chat_id"]
        env["TELEGRAM_CHAT_ID"] = cred["chat_id"]
    # Make Python child output appear immediately in the panel.
    env["PYTHONUNBUFFERED"] = "1"
    return env


def format_exit_reason(returncode, stop_requested=False):
    if stop_requested:
        return f"Stopped by panel (exit code {returncode})."
    if returncode == 0:
        return "Process exited normally (exit code 0)."
    if returncode is None:
        return "Process status is unknown."
    if returncode < 0:
        return f"Process terminated by signal {-returncode} (exit code {returncode})."
    return f"Process crashed/exited with code {returncode}. Check the logs above for the traceback or error."


def capture_output(bot_id, process):
    """Continuously drain stdout/stderr so child processes cannot block on a full pipe."""
    try:
        if process.stdout is None:
            return
        for line in iter(process.stdout.readline, ""):
            if not line:
                break
            append_log(bot_id, line.rstrip("\r\n"))
    except Exception as exc:
        append_log(bot_id, f"[Panel log reader error] {type(exc).__name__}: {exc}")
    finally:
        try:
            if process.stdout:
                process.stdout.close()
        except Exception:
            pass


def monitor_process(bot_id, process):
    """Wait for a child process and record its real exit reason."""
    try:
        returncode = process.wait()

        # Give the output reader a moment to consume the final traceback lines.
        reader = process_meta.get(bot_id, {}).get("reader")
        if reader and reader is not threading.current_thread():
            reader.join(timeout=2)

        with state_lock:
            meta = process_meta.get(bot_id, {})
            stop_requested = bool(meta.get("stop_requested"))
            # Only clear the process reference if it still points to this process.
            if processes.get(bot_id) is process:
                processes.pop(bot_id, None)
            if process_meta.get(bot_id, {}).get("process") is process:
                process_meta[bot_id]["returncode"] = returncode
                process_meta[bot_id]["running"] = False

        reason = format_exit_reason(returncode, stop_requested)
        with state_lock:
            process_meta.setdefault(bot_id, {})["last_exit"] = reason
        append_log(bot_id, f"[PROCESS ENDED] {reason}")
    except Exception as exc:
        append_log(bot_id, f"[Panel monitor error] {type(exc).__name__}: {exc}")


def launch_bot(bot_id, action_label):
    script = BOT_DIR / f"{bot_id}.py"
    if not script.exists():
        raise FileNotFoundError(f"Bot file not found: {script.name}")

    # -u forces unbuffered Python stdout/stderr, while the reader thread below
    # continuously drains the pipe. This prevents hidden errors and pipe deadlocks.
    process = subprocess.Popen(
        [sys.executable, "-u", str(script)],
        cwd=str(BOT_DIR),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
        env=bot_environment(bot_id),
    )

    reader = threading.Thread(
        target=capture_output,
        args=(bot_id, process),
        name=f"log-reader-{bot_id}-{process.pid}",
        daemon=True,
    )
    with state_lock:
        processes[bot_id] = process
        process_meta[bot_id] = {
            "process": process,
            "reader": reader,
            "stop_requested": False,
            "returncode": None,
            "running": True,
            "started_at": now(),
        }
    reader.start()
    threading.Thread(
        target=monitor_process,
        args=(bot_id, process),
        name=f"process-monitor-{bot_id}-{process.pid}",
        daemon=True,
    ).start()
    append_log(bot_id, f"{action_label} PID {process.pid}")
    return process


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "error": None})


@app.post("/login")
async def login(request: Request, username: str = Form(...), password: str = Form(...)):
    if username == USER and password == PASSWORD:
        request.session["user"] = username
        return RedirectResponse("/", status_code=303)
    return templates.TemplateResponse("login.html", {"request": request, "error": "Invalid login"})


@app.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)

    bots = []
    for p in sorted(BOT_DIR.glob("*.py")):
        bots.append({
            "id": p.stem,
            "name": p.name,
            "status": status(p.stem),
            "last_exit": process_meta.get(p.stem, {}).get("last_exit", ""),
        })

    return templates.TemplateResponse(
        "dashboard.html",
        {"request": request, "bots": bots, "logs": logs}
    )


@app.post("/bots/upload")
async def upload(request: Request, bot_name: str = Form(...), bot_file: UploadFile = File(...)):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)

    name = Path(bot_name).name
    if not name.endswith(".py"):
        name += ".py"

    data = await bot_file.read()
    (BOT_DIR / name).write_bytes(data)
    append_log(Path(name).stem, f"Uploaded {name}")
    return RedirectResponse("/", status_code=303)


@app.post("/bots/{bot_id}/start")
async def start(request: Request, bot_id: str):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)

    script = BOT_DIR / f"{bot_id}.py"
    if not script.exists() or status(bot_id) == "running":
        return RedirectResponse("/", status_code=303)

    try:
        launch_bot(bot_id, "Started")
    except Exception as exc:
        append_log(bot_id, f"[START ERROR] {type(exc).__name__}: {exc}")

    return RedirectResponse("/", status_code=303)


@app.post("/bots/{bot_id}/stop")
async def stop(request: Request, bot_id: str):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)

    with state_lock:
        p = processes.get(bot_id)
        if p and p.poll() is None:
            process_meta.setdefault(bot_id, {})["stop_requested"] = True

    if p and p.poll() is None:
        append_log(bot_id, "Stop requested by panel.")
        try:
            p.terminate()
        except Exception as exc:
            append_log(bot_id, f"[STOP ERROR] {type(exc).__name__}: {exc}")
    return RedirectResponse("/", status_code=303)


@app.post("/bots/{bot_id}/restart")
async def restart(request: Request, bot_id: str):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)

    with state_lock:
        old = processes.get(bot_id)
        if old and old.poll() is None:
            process_meta.setdefault(bot_id, {})["stop_requested"] = True

    if old and old.poll() is None:
        append_log(bot_id, "Restart requested: stopping previous process.")
        try:
            old.terminate()
            old.wait(timeout=5)
        except subprocess.TimeoutExpired:
            append_log(bot_id, "Previous process did not stop within 5 seconds; killing it.")
            old.kill()
            old.wait(timeout=5)
        except Exception as exc:
            append_log(bot_id, f"[RESTART STOP ERROR] {type(exc).__name__}: {exc}")

    script = BOT_DIR / f"{bot_id}.py"
    if script.exists():
        try:
            launch_bot(bot_id, "Restarted")
        except Exception as exc:
            append_log(bot_id, f"[RESTART ERROR] {type(exc).__name__}: {exc}")

    return RedirectResponse("/", status_code=303)


@app.get("/credentials", response_class=HTMLResponse)
async def credentials_page(request: Request):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)
    bots = sorted(BOT_DIR.glob("*.py"))
    saved = {bot_id: {"has_token": bool(v.get("token")), "chat_id": v.get("chat_id", "")}
             for bot_id, v in credentials.items()}
    return templates.TemplateResponse(
        "credentials.html",
        {"request": request, "bots": bots, "saved": saved}
    )


@app.post("/credentials")
async def save_credentials(
    request: Request,
    bot_id: str = Form(...),
    token: str = Form(""),
    chat_id: str = Form("")
):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)

    bot_id = Path(bot_id).stem
    if not (BOT_DIR / f"{bot_id}.py").exists():
        return RedirectResponse("/credentials", status_code=303)

    token = token.strip()
    chat_id = chat_id.strip()
    current = credentials.get(bot_id, {})
    if token:
        current["token"] = token
    if chat_id:
        current["chat_id"] = chat_id
    credentials[bot_id] = current
    append_log(bot_id, "Credentials updated (secret values are not logged).")
    return RedirectResponse("/credentials", status_code=303)


@app.post("/credentials/{bot_id}/clear")
async def clear_credentials(request: Request, bot_id: str):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)
    credentials.pop(Path(bot_id).stem, None)
    append_log(Path(bot_id).stem, "Credentials cleared.")
    return RedirectResponse("/credentials", status_code=303)


@app.get("/api/logs/{bot_id}")
async def get_logs(request: Request, bot_id: str):
    if not logged(request):
        return {"error": "unauthorized"}
    with state_lock:
        current = list(logs.get(bot_id, [])[-100:])
    return {"logs": current}


@app.get("/api/status")
async def get_status(request: Request):
    if not logged(request):
        return {"error": "unauthorized"}

    result = {}
    for p in BOT_DIR.glob("*.py"):
        bot_id = p.stem
        with state_lock:
            meta = dict(process_meta.get(bot_id, {}))
        result[bot_id] = {
            "status": status(bot_id),
            "pid": meta.get("process").pid if meta.get("process") and meta.get("process").poll() is None else None,
            "started_at": meta.get("started_at"),
            "last_exit": meta.get("last_exit", ""),
        }
    return result
