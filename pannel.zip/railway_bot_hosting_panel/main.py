import os, sys, subprocess
from pathlib import Path
from fastapi import FastAPI, Request, Form, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

BASE = Path(__file__).parent
BOT_DIR = BASE / "bots"
BOT_DIR.mkdir(exist_ok=True)

app = FastAPI(title="Bot Hosting Panel")
app.add_middleware(
    SessionMiddleware,
    secret_key=os.getenv("SESSION_SECRET", "replace-this-in-railway")
)
templates = Jinja2Templates(directory=str(BASE / "templates"))

USER = os.getenv("PANEL_USER", "admin")
PASSWORD = os.getenv("PANEL_PASSWORD", "change-me")

processes = {}
logs = {}
# Credentials are kept outside the Git repository. For production, replace this
# in-memory store with an encrypted database/secret manager.
credentials = {}

def logged(request):
    return bool(request.session.get("user"))

def status(bot_id):
    p = processes.get(bot_id)
    return "running" if p and p.poll() is None else "stopped"

def bot_environment(bot_id):
    env = os.environ.copy()
    cred = credentials.get(bot_id, {})
    if cred.get("token"):
        env["BOT_TOKEN"] = cred["token"]
        env["TELEGRAM_BOT_TOKEN"] = cred["token"]
    if cred.get("chat_id"):
        env["CHAT_ID"] = cred["chat_id"]
        env["TELEGRAM_CHAT_ID"] = cred["chat_id"]
    return env

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "error": None})

@app.post("/login")
async def login(request: Request, username: str = Form(...), password: str = Form(...)):
    if username == USER and password == PASSWORD:
        request.session["user"] = username
        return RedirectResponse("/", status_code=303)
    return templates.TemplateResponse("login.html", {"request": request, "error": "Invalid login"})

@app.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)

    bots = []
    for p in sorted(BOT_DIR.glob("*.py")):
        bots.append({"id": p.stem, "name": p.name, "status": status(p.stem)})

    return templates.TemplateResponse(
        "dashboard.html",
        {"request": request, "bots": bots, "logs": logs}
    )

@app.post("/bots/upload")
async def upload(request: Request, bot_name: str = Form(...), bot_file: UploadFile = File(...)):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)

    name = Path(bot_name).name
    if not name.endswith(".py"):
        name += ".py"

    data = await bot_file.read()
    (BOT_DIR / name).write_bytes(data)
    logs.setdefault(Path(name).stem, []).append(f"Uploaded {name}")
    return RedirectResponse("/", status_code=303)

@app.post("/bots/{bot_id}/start")
async def start(request: Request, bot_id: str):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)

    script = BOT_DIR / f"{bot_id}.py"
    if not script.exists() or status(bot_id) == "running":
        return RedirectResponse("/", status_code=303)

    try:
        p = subprocess.Popen(
            [sys.executable, str(script)],
            cwd=str(BOT_DIR),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            env=bot_environment(bot_id)
        )
        processes[bot_id] = p
        logs.setdefault(bot_id, []).append(f"Started PID {p.pid}")
    except Exception as e:
        logs.setdefault(bot_id, []).append(f"Start error: {e}")

    return RedirectResponse("/", status_code=303)

@app.post("/bots/{bot_id}/stop")
async def stop(request: Request, bot_id: str):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)

    p = processes.get(bot_id)
    if p and p.poll() is None:
        p.terminate()
        logs.setdefault(bot_id, []).append("Stop requested")
    return RedirectResponse("/", status_code=303)

@app.post("/bots/{bot_id}/restart")
async def restart(request: Request, bot_id: str):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)

    p = processes.get(bot_id)
    if p and p.poll() is None:
        p.terminate()

    script = BOT_DIR / f"{bot_id}.py"
    if script.exists():
        try:
            p = subprocess.Popen(
                [sys.executable, str(script)],
                cwd=str(BOT_DIR),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                env=bot_environment(bot_id)
            )
            processes[bot_id] = p
            logs.setdefault(bot_id, []).append(f"Restarted PID {p.pid}")
        except Exception as e:
            logs.setdefault(bot_id, []).append(f"Restart error: {e}")

    return RedirectResponse("/", status_code=303)

@app.get("/credentials", response_class=HTMLResponse)
async def credentials_page(request: Request):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)
    bots = sorted(BOT_DIR.glob("*.py"))
    saved = {bot_id: {"has_token": bool(v.get("token")), "chat_id": v.get("chat_id", "")}
             for bot_id, v in credentials.items()}
    return templates.TemplateResponse(
        "credentials.html",
        {"request": request, "bots": bots, "saved": saved}
    )

@app.post("/credentials")
async def save_credentials(
    request: Request,
    bot_id: str = Form(...),
    token: str = Form(""),
    chat_id: str = Form("")
):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)

    bot_id = Path(bot_id).stem
    if not (BOT_DIR / f"{bot_id}.py").exists():
        return RedirectResponse("/credentials", status_code=303)

    token = token.strip()
    chat_id = chat_id.strip()
    current = credentials.get(bot_id, {})
    if token:
        current["token"] = token
    if chat_id:
        current["chat_id"] = chat_id
    credentials[bot_id] = current
    logs.setdefault(bot_id, []).append("Credentials updated (secret values are not logged).")
    return RedirectResponse("/credentials", status_code=303)

@app.post("/credentials/{bot_id}/clear")
async def clear_credentials(request: Request, bot_id: str):
    if not logged(request):
        return RedirectResponse("/login", status_code=303)
    credentials.pop(Path(bot_id).stem, None)
    logs.setdefault(Path(bot_id).stem, []).append("Credentials cleared.")
    return RedirectResponse("/credentials", status_code=303)

@app.get("/api/logs/{bot_id}")
async def get_logs(request: Request, bot_id: str):
    if not logged(request):
        return {"error": "unauthorized"}
    return {"logs": logs.get(bot_id, [])[-100:]}

@app.get("/api/status")
async def get_status(request: Request):
    if not logged(request):
        return {"error": "unauthorized"}
    return {p.stem: status(p.stem) for p in BOT_DIR.glob("*.py")}
